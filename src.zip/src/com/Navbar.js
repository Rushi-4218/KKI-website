"use client";

import React, { useEffect, useState } from "react";

import {
  ArrowRight,
  ChefHat,
  ChevronDown,
  Download,
  Droplets,
  Factory,
  Flame,
  Mail,
  Menu,
  MessageCircle,
  Phone,
  Ship,
  Snowflake,
  Sparkles,
  Utensils,
  Wind,
  Wrench,
  X,
} from "lucide-react";

import Image from "next/image";
import Link from "next/link";

import { usePathname } from "next/navigation";

import {
  CONTACT,
  PRODUCT_CATEGORIES,
} from "./SiteData";


const CATEGORY_ICONS = {
  "cooking-equipment": Flame,
  "preparation-equipment": ChefHat,
  "storage-equipment": Snowflake,
  "serving-equipment": Utensils,
  "washing-equipment": Droplets,
  "bakery-equipment": ChefHat,
  "galley-equipment": Ship,
  "exhaust-ventilation": Wind,
  "custom-fabrication": Wrench,
};


const FALLBACK_CATEGORIES = PRODUCT_CATEGORIES.map((item) => ({
  slug: item.slug,
  name: item.name,
  desc: item.desc,
  link: `/products/${item.slug}`,
}));


const NAV_LINKS = [
  {
    label: "Home",
    href: "/",
  },
  {
    label: "About KKI",
    href: "/about",
  },
  {
    label: "Marine & Galley",
    href: "/marine-galley",
  },
  {
    label: "Projects",
    href: "/projects",
  },
  {
    label: "Contact",
    href: "/contact",
  },
];


export default function Navbar() {
  const pathname = usePathname();

  const [isMenuOpen, setIsMenuOpen] =
    useState(false);

  const [showProducts, setShowProducts] =
    useState(false);

  const [isScrolled, setIsScrolled] =
    useState(false);

  const [productCategories, setProductCategories] =
    useState(FALLBACK_CATEGORIES);


  /* =========================================================
     SCROLL STATE
  ========================================================= */

  useEffect(() => {
    const onScroll = () => {
      setIsScrolled(window.scrollY > 28);
    };

    window.addEventListener(
      "scroll",
      onScroll,
      {
        passive: true,
      }
    );

    onScroll();

    return () => {
      window.removeEventListener(
        "scroll",
        onScroll
      );
    };
  }, []);


  /* =========================================================
     CLOSE MENUS ON ROUTE CHANGE
  ========================================================= */

  useEffect(() => {
    setIsMenuOpen(false);
    setShowProducts(false);
  }, [pathname]);


  /* =========================================================
     ESCAPE KEY
  ========================================================= */

  useEffect(() => {
    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setIsMenuOpen(false);
        setShowProducts(false);
      }
    };

    window.addEventListener(
      "keydown",
      handleKeyDown
    );

    return () => {
      window.removeEventListener(
        "keydown",
        handleKeyDown
      );
    };
  }, []);


  /* =========================================================
     MOBILE BODY LOCK
  ========================================================= */

  useEffect(() => {
    if (!isMenuOpen) {
      document.body.style.overflow = "";
      return;
    }

    document.body.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = "";
    };
  }, [isMenuOpen]);


  /* =========================================================
     DATABASE CATEGORIES
  ========================================================= */

  useEffect(() => {
    let active = true;

    async function fetchCategories() {
      try {
        const response =
          await fetch("/api/category");

        const data =
          await response.json();

        if (
          !active ||
          !data?.success ||
          !data?.categories?.length
        ) {
          return;
        }

        const descriptions =
          Object.fromEntries(
            PRODUCT_CATEGORIES.map(
              (item) => [
                item.slug,
                item.desc,
              ]
            )
          );

        const categories =
          data.categories
            .filter(
              (category) =>
                category.slug
            )
            .map(
              (category) => ({
                slug:
                  category.slug,

                name:
                  category.name,

                desc:
                  descriptions[
                    category.slug
                  ] ||
                  "Commercial kitchen equipment engineered for professional use.",

                link:
                  `/products/${category.slug}`,
              })
            );

        if (categories.length) {
          setProductCategories(
            categories
          );
        }
      } catch {
        // Use fallback categories if API is unavailable.
      }
    }

    fetchCategories();

    return () => {
      active = false;
    };
  }, []);


  const isActive = (href) => {
    if (href === "/") {
      return pathname === "/";
    }

    return (
      pathname === href ||
      pathname?.startsWith(
        `${href}/`
      )
    );
  };


  const productsActive =
    pathname?.startsWith(
      "/products"
    ) ||
    pathname?.startsWith(
      "/product/"
    );


  return (
    <header
      className="
        fixed
        inset-x-0
        top-0
        z-[100]
      "
    >

      {/* =====================================================
          TOP CONTACT BAR
      ===================================================== */}

      <div
        className={`
          hidden
          overflow-hidden
          bg-[var(--navy-950)]
          text-white
          transition-all
          duration-300
          md:block

          ${
            isScrolled
              ? "max-h-0 opacity-0"
              : "max-h-9 opacity-100"
          }
        `}
      >
        <div
          className="
            mx-auto
            flex
            h-9
            max-w-7xl
            items-center
            justify-between
            px-5
            text-[11px]
            font-semibold
            tracking-wide
            lg:px-8
          "
        >
          <div
            className="
              flex
              items-center
              gap-5
            "
          >
            <a
              href={`tel:${CONTACT.phonePrimaryRaw}`}
              className="
                inline-flex
                items-center
                gap-1.5

                transition-colors
                hover:text-[var(--gold-300)]
              "
            >
              <Phone
                size={12}
                className="text-[var(--gold-400)]"
              />

              {CONTACT.phonePrimary}
            </a>

            <a
              href={`mailto:${CONTACT.email}`}
              className="
                inline-flex
                items-center
                gap-1.5

                transition-colors
                hover:text-[var(--gold-300)]
              "
            >
              <Mail
                size={12}
                className="text-[var(--gold-400)]"
              />

              {CONTACT.email}
            </a>

            <a
              href={CONTACT.whatsappLink}
              target="_blank"
              rel="noreferrer"
              className="
                hidden
                items-center
                gap-1.5

                transition-colors
                hover:text-[var(--gold-300)]
                sm:inline-flex
              "
            >
              <MessageCircle
                size={12}
                className="text-[var(--gold-400)]"
              />

              WhatsApp Us
            </a>
          </div>

          <p
            className="
              uppercase
              tracking-[0.17em]
              text-white/70
            "
          >
            Design • Fabrication •
            Installation • AMC
          </p>
        </div>
      </div>


      {/* =====================================================
          MAIN NAVBAR
      ===================================================== */}

      <nav
        className={`
          border-b
          transition-all
          duration-300

          ${
            isScrolled
              ? `
                border-black/[0.06]
                bg-white/[0.92]
                shadow-[0_14px_42px_rgba(3,24,45,0.11)]
                backdrop-blur-2xl
              `
              : `
                border-black/[0.05]
                bg-white
                shadow-sm
              `
          }
        `}
      >
        <div
          className="
            mx-auto
            max-w-7xl
            px-4
            sm:px-6
            lg:px-8
          "
        >
          <div
            className={`
              flex
              items-center
              justify-between

              transition-all
              duration-300

              ${
                isScrolled
                  ? "h-[82px]"
                  : "h-[104px]"
              }
            `}
          >

            {/* LOGO */}

            <Link
              href="/"
              aria-label="Kitchen King Industries home"
              className="
                flex
                min-w-0
                items-center
              "
            >
              <Image
                src="/logo.PNG"
                alt="Kitchen King Industries"
                width={210}
                height={235}
                priority

                /* IMPORTANT:
                   Keep this attribute.
                   BrandIntro uses it as
                   the navbar destination.
                */
                data-kki-nav-logo

                className={`
                  w-auto
                  object-contain

                  transition-all
                  duration-300

                  ${
                    isScrolled
                      ? "h-[70px]"
                      : "h-[90px]"
                  }
                `}
              />
            </Link>


            {/* =================================================
                DESKTOP NAVIGATION
            ================================================= */}

            <div
              className="
                hidden
                items-center
                gap-0.5
                xl:flex
              "
            >
              {NAV_LINKS
                .slice(0, 2)
                .map(
                  ({
                    label,
                    href,
                  }) => (
                    <Link
                      key={href}
                      href={href}
                      className={`
                        nav-link-premium

                        ${
                          isActive(
                            href
                          )
                            ? "is-active"
                            : ""
                        }
                      `}
                    >
                      {label}
                    </Link>
                  )
                )}


              {/* PRODUCTS MEGA MENU */}

              <div
                className="relative"
                onMouseEnter={() =>
                  setShowProducts(
                    true
                  )
                }
                onMouseLeave={() =>
                  setShowProducts(
                    false
                  )
                }
              >
                <Link
                  href="/products"
                  className={`
                    nav-link-premium
                    inline-flex
                    items-center
                    gap-1

                    ${
                      productsActive
                        ? "is-active"
                        : ""
                    }
                  `}
                  aria-expanded={
                    showProducts
                  }
                >
                  Products

                  <ChevronDown
                    size={14}
                    className={`
                      transition-transform
                      duration-300

                      ${
                        showProducts
                          ? "rotate-180"
                          : ""
                      }
                    `}
                  />
                </Link>


                {showProducts && (
                  <div
                    className="
                      absolute
                      left-1/2
                      top-full
                      w-[920px]
                      -translate-x-1/2
                      pt-3
                    "
                  >
                    <div
                      className="
                        animate-fadeInDown
                        overflow-hidden
                        rounded-[26px]
                        border
                        border-[var(--line-light)]
                        bg-white
                        shadow-[0_32px_90px_rgba(3,24,45,0.20)]
                      "
                    >

                      {/* MENU HEADER */}

                      <div
                        className="
                          flex
                          items-center
                          justify-between
                          border-b
                          border-[var(--line-light)]
                          bg-[var(--surface-soft)]
                          px-6
                          py-4
                        "
                      >
                        <div>
                          <p
                            className="
                              text-[10px]
                              font-extrabold
                              uppercase
                              tracking-[0.2em]
                              text-[var(--gold-500)]
                            "
                          >
                            Product Range
                          </p>

                          <p
                            className="
                              mt-1
                              text-sm
                              font-semibold
                              text-[var(--navy-950)]
                            "
                          >
                            Commercial kitchen
                            and galley equipment
                          </p>
                        </div>

                        <Link
                          href="/products"
                          className="
                            inline-flex
                            items-center
                            gap-2

                            text-xs
                            font-extrabold
                            uppercase
                            tracking-[0.08em]
                            text-[var(--navy-900)]

                            transition-colors
                            hover:text-[var(--gold-500)]
                          "
                        >
                          View All

                          <ArrowRight
                            size={14}
                          />
                        </Link>
                      </div>


                      <div
                        className="
                          grid
                          grid-cols-[1fr_245px]
                        "
                      >

                        {/* CATEGORY GRID */}

                        <div
                          className="
                            grid
                            grid-cols-3
                            gap-2
                            p-5
                          "
                        >
                          {productCategories.map(
                            (
                              category
                            ) => {
                              const Icon =
                                CATEGORY_ICONS[
                                  category
                                    .slug
                                ] ||
                                Factory;

                              return (
                                <Link
                                  key={
                                    category.slug
                                  }
                                  href={
                                    category.link
                                  }
                                  className="
                                    group
                                    rounded-2xl
                                    border
                                    border-transparent
                                    p-4

                                    transition-all
                                    duration-250

                                    hover:border-[var(--gold-400)]/30
                                    hover:bg-[var(--surface-cream)]
                                  "
                                >
                                  <div
                                    className="
                                      flex
                                      items-start
                                      gap-3
                                    "
                                  >
                                    <div
                                      className="
                                        flex
                                        h-10
                                        w-10
                                        shrink-0
                                        items-center
                                        justify-center
                                        rounded-xl
                                        border
                                        border-[var(--gold-400)]/25
                                        bg-[var(--navy-950)]

                                        transition-transform
                                        duration-300

                                        group-hover:-translate-y-0.5
                                      "
                                    >
                                      <Icon
                                        size={
                                          17
                                        }
                                        strokeWidth={
                                          1.7
                                        }
                                        className="
                                          text-[var(--gold-300)]
                                        "
                                      />
                                    </div>

                                    <div
                                      className="
                                        min-w-0
                                      "
                                    >
                                      <p
                                        className="
                                          text-[13px]
                                          font-bold
                                          leading-tight
                                          text-[var(--navy-950)]

                                          transition-colors
                                          group-hover:text-[var(--gold-500)]
                                        "
                                      >
                                        {
                                          category.name
                                        }
                                      </p>

                                      <p
                                        className="
                                          mt-1.5
                                          line-clamp-2
                                          text-[10px]
                                          font-medium
                                          leading-relaxed
                                          text-[var(--muted-light)]
                                        "
                                      >
                                        {
                                          category.desc
                                        }
                                      </p>
                                    </div>
                                  </div>
                                </Link>
                              );
                            }
                          )}
                        </div>


                        {/* MEGA MENU CTA */}

                        <div
                          className="
                            relative
                            overflow-hidden
                            bg-[var(--navy-950)]
                            p-6
                          "
                        >
                          <div
                            className="
                              absolute
                              inset-0
                              hero-grid
                              opacity-20
                            "
                          />

                          <div
                            className="
                              relative
                            "
                          >
                            <Sparkles
                              size={24}
                              className="
                                text-[var(--gold-300)]
                              "
                            />

                            <p
                              className="
                                mt-5
                                text-[10px]
                                font-extrabold
                                uppercase
                                tracking-[0.18em]
                                text-[var(--gold-300)]
                              "
                            >
                              Custom Requirement?
                            </p>

                            <h3
                              className="
                                mt-2
                                font-display
                                text-xl
                                font-bold
                                leading-tight
                                text-white
                              "
                            >
                              Equipment built
                              around your kitchen.
                            </h3>

                            <p
                              className="
                                mt-3
                                text-xs
                                font-medium
                                leading-relaxed
                                text-[var(--muted-dark)]
                              "
                            >
                              Share your layout,
                              capacity or equipment
                              requirement with our
                              team.
                            </p>

                            <Link
                              href="/contact"
                              className="
                                mt-5
                                inline-flex
                                items-center
                                gap-2

                                rounded-full
                                bg-[var(--gold-300)]
                                px-4
                                py-2.5

                                text-[10px]
                                font-extrabold
                                uppercase
                                tracking-[0.08em]
                                text-[var(--navy-950)]

                                transition-transform
                                hover:-translate-y-0.5
                              "
                            >
                              Request Quote

                              <ArrowRight
                                size={13}
                              />
                            </Link>

                            <a
                              href="/catalogues/kitchen-king-product-catalogue-2026-27.pdf"
                              target="_blank"
                              rel="noreferrer"
                              className="
                                mt-4
                                flex
                                items-center
                                gap-2
                                text-[10px]
                                font-bold
                                text-white/70

                                transition-colors
                                hover:text-white
                              "
                            >
                              <Download
                                size={12}
                              />

                              Product Catalogue
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>


              {NAV_LINKS
                .slice(2)
                .map(
                  ({
                    label,
                    href,
                  }) => (
                    <Link
                      key={href}
                      href={href}
                      className={`
                        nav-link-premium

                        ${
                          isActive(
                            href
                          )
                            ? "is-active"
                            : ""
                        }
                      `}
                    >
                      {label}
                    </Link>
                  )
                )}


              <Link
                href="/contact"
                className="
                  ml-3
                  inline-flex
                  items-center
                  gap-2

                  rounded-full

                  bg-[var(--navy-950)]
                  px-5
                  py-3

                  text-sm
                  font-bold
                  uppercase
                  tracking-[0.08em]
                  text-white

                  shadow-lg
                  shadow-[var(--navy-950)]/10

                  transition-all
                  duration-300

                  hover:-translate-y-0.5
                  hover:bg-[var(--gold-500)]
                  hover:shadow-xl
                "
              >
                Request Quote

                <ArrowRight
                  size={14}
                />
              </Link>
            </div>


            {/* =================================================
                MOBILE BUTTON
            ================================================= */}

            <button
              type="button"

              className="
                inline-flex
                h-11
                w-11
                items-center
                justify-center

                rounded-full
                border
                border-[var(--line-light)]

                text-[var(--navy-950)]

                transition-all

                hover:border-[var(--gold-400)]
                hover:text-[var(--gold-500)]

                xl:hidden
              "

              onClick={() =>
                setIsMenuOpen(
                  (value) =>
                    !value
                )
              }

              aria-label="Toggle navigation"

              aria-expanded={
                isMenuOpen
              }
            >
              {isMenuOpen ? (
                <X size={21} />
              ) : (
                <Menu size={21} />
              )}
            </button>
          </div>
        </div>


        {/* =====================================================
            MOBILE MENU
        ===================================================== */}

        {isMenuOpen && (
          <div
            className="
              animate-fadeInDown
              max-h-[calc(100vh-82px)]
              overflow-y-auto
              border-t
              border-[var(--line-light)]
              bg-white

              xl:hidden
            "
          >
            <div
              className="
                mx-auto
                max-w-7xl
                px-4
                py-5
                sm:px-6
              "
            >

              {NAV_LINKS
                .slice(0, 2)
                .map(
                  ({
                    label,
                    href,
                  }) => (
                    <Link
                      key={href}
                      href={href}
                      className={`
                        mobile-nav-link

                        ${
                          isActive(
                            href
                          )
                            ? "text-[var(--gold-500)]"
                            : ""
                        }
                      `}
                    >
                      {label}
                    </Link>
                  )
                )}


              <button
                type="button"
                onClick={() =>
                  setShowProducts(
                    (value) =>
                      !value
                  )
                }
                className="
                  mobile-nav-link
                  flex
                  items-center
                  justify-between
                  text-left
                "
              >
                Products

                <ChevronDown
                  size={16}
                  className={`
                    transition-transform
                    duration-300

                    ${
                      showProducts
                        ? "rotate-180"
                        : ""
                    }
                  `}
                />
              </button>


              {showProducts && (
                <div
                  className="
                    my-2
                    grid
                    gap-1
                    rounded-2xl
                    bg-[var(--surface-cream)]
                    p-2
                    sm:grid-cols-2
                  "
                >
                  {productCategories.map(
                    (
                      category
                    ) => {
                      const Icon =
                        CATEGORY_ICONS[
                          category.slug
                        ] ||
                        Factory;

                      return (
                        <Link
                          key={
                            category.slug
                          }
                          href={
                            category.link
                          }
                          className="
                            flex
                            items-center
                            gap-3

                            rounded-xl
                            px-3
                            py-3

                            text-sm
                            font-semibold
                            text-[var(--navy-900)]

                            transition-colors

                            hover:bg-white
                            hover:text-[var(--gold-500)]
                          "
                        >
                          <Icon
                            size={16}
                            className="
                              shrink-0
                              text-[var(--gold-500)]
                            "
                          />

                          {category.name}
                        </Link>
                      );
                    }
                  )}
                </div>
              )}


              {NAV_LINKS
                .slice(2)
                .map(
                  ({
                    label,
                    href,
                  }) => (
                    <Link
                      key={href}
                      href={href}
                      className={`
                        mobile-nav-link

                        ${
                          isActive(
                            href
                          )
                            ? "text-[var(--gold-500)]"
                            : ""
                        }
                      `}
                    >
                      {label}
                    </Link>
                  )
                )}


              <div
                className="
                  mt-5
                  grid
                  gap-3
                  border-t
                  border-[var(--line-light)]
                  pt-5
                  sm:grid-cols-2
                "
              >
                <a
                  href={`tel:${CONTACT.phonePrimaryRaw}`}
                  className="
                    flex
                    items-center
                    gap-3
                    rounded-xl
                    bg-[var(--surface-cream)]
                    p-4
                    text-sm
                    font-semibold
                    text-[var(--navy-950)]
                  "
                >
                  <Phone
                    size={17}
                    className="
                      text-[var(--gold-500)]
                    "
                  />

                  {CONTACT.phonePrimary}
                </a>

                <Link
                  href="/contact"
                  className="
                    inline-flex
                    items-center
                    justify-center
                    gap-2

                    rounded-xl

                    bg-[var(--navy-950)]
                    px-5
                    py-4

                    text-sm
                    font-bold
                    text-white
                  "
                >
                  Request Quote

                  <ArrowRight
                    size={15}
                  />
                </Link>
              </div>
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}